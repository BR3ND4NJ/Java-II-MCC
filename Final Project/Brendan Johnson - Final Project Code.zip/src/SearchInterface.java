interface SearchInterface {
    public int getId();

    public String getViewString();
}
