import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;


public class Main {
    public static void main(String[] args) {
        Accounts a = new Accounts();
        MainScreen w = new MainScreen(a);
    }
}